let nombre="Silvia ";
let apellido="Jesús";

let nombreCompleto= nombre+ ""+apellido;

console.log("Desafio 1");
console.log("Mi nombre completo es: "+nombreCompleto);

alert("Buen dia "+nombreCompleto);


let nuevoNombre= prompt("Ingrese su nombre");
alert("Como estás "+nuevoNombre);
let edad=parseInt(prompt("Ingrese su edad"));
let sumaNumero= edad + 5;
console.log("En 5 años tendrás: " +sumaNumero);